package beans;

public class EmployeeBean {
	private String emCode;
	private String emPassword;
	private String emName;
	private String emBwCode;
	private String date;
	private String accessType;
	
	public String getAccessType() {
		return accessType;
	}
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEmCode() {
		return emCode;
	}
	public void setEmCode(String emCode) {
		this.emCode = emCode;
	}
	public String getEmPassword() {
		return emPassword;
	}
	public void setEmPassword(String emPassword) {
		this.emPassword = emPassword;
	}
	public String getEmName() {
		return emName;
	}
	public void setEmName(String emName) {
		this.emName = emName;
	}
	public String getEmBwCode() {
		return emBwCode;
	}
	public void setEmBwCode(String emBwCode) {
		this.emBwCode = emBwCode;
	}
	
	
}
